__author__ = 'simon'

from pycdl import CDL, ColorDecision, ColorCorrection

__version__ = '0.0.3'
